package com.example.cuaca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
